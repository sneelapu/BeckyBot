﻿using System;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;

namespace EmptyBot
{
    public class MultiTurnPromptsBotAccessors
    {
        // Initializes a new instance of the class.
        public MultiTurnPromptsBotAccessors(ConversationState conversationState, UserState userState)
        {
            ConversationState = conversationState ?? throw new ArgumentNullException(nameof(conversationState));
            UserState = userState ?? throw new ArgumentNullException(nameof(userState));
        }
        public static string UserProfileName { get; } = "UserProfile";

        public static string ConversationDataName { get; } = "ConversationData";
        public IStatePropertyAccessor<DialogState> ConversationDialogState { get; set; }
       public IStatePropertyAccessor<UserProfile> UserProfile { get; set; }
        public IStatePropertyAccessor<RoomProfile> RoomProfile { get; set; }
        public IStatePropertyAccessor<LeaveProfile> LeaveProfile { get; set; }

        public ConversationState ConversationState { get; }
        public UserState UserState { get; }
        //public static string UserProfileName { get; } = "UserProfile";

       // public static string ConversationDataName { get; } = "ConversationData";

        public IStatePropertyAccessor<UserProfile> UserProfileAccessor { get; set; }

        public IStatePropertyAccessor<ConversationData> ConversationDataAccessor { get; set; }

        
    }
}
