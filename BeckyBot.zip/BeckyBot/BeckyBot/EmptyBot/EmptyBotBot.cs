﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace EmptyBot
{
    public class EmptyBotBot : IBot
    {
        public const string leavedetails = "leavedetails";
      
        private readonly MultiTurnPromptsBotAccessors _accessors;
        private DialogSet _dialogs;
        private const string DispatchKey = "dispatch";
        public static readonly string LuisKey = "LuisBot";
        public static readonly string QnAKey = "QnABot";
        private readonly BotServices _services;
        //private readonly string QnAMakerKey = "QnABot";

        public EmptyBotBot(MultiTurnPromptsBotAccessors accessors, BotServices services,ILoggerFactory loggerFactory)
        {
            _services = services ?? throw new System.ArgumentNullException(nameof(services));

            if (!_services.QnAServices.ContainsKey(QnAKey))
            {
                throw new System.ArgumentException($"Invalid configuration. Please check your '.bot' file for a QnA service named '{QnAKey}'.");
            }

            if (!_services.LuisServices.ContainsKey(LuisKey))
            {
                throw new System.ArgumentException($"Invalid configuration. Please check your '.bot' file for a LUIS service named '{LuisKey}'.");
            }

            _accessors = accessors ?? throw new ArgumentNullException(nameof(accessors));
            // The DialogSet needs a DialogState accessor, it will call it when it has a turn context.
            _dialogs = new DialogSet(accessors.ConversationDialogState);

            var waterfallSteps = new WaterfallStep[]
            {
                IdStepAsync,
                IDConfirmStepAsync,
            };

            ////Add named dialogs to the DialogSet. These names are saved in the dialog state.
            _dialogs.Add(new WaterfallDialog("details", waterfallSteps));
            _dialogs.Add(new TextPrompt("textPrompt"));

            var LeavewaterfallSteps = new WaterfallStep[]
            {
                LeaveName,
                LeaveStartingDate,
               LeaveEndingDate,
                LeaveReason,
                LeaveReasonConformation,
                LeaveConformation,
            };
            _dialogs.Add(new WaterfallDialog("leavedetails", LeavewaterfallSteps));
            _dialogs.Add(new TextPrompt("textPrompt1"));
            _dialogs.Add(new DateTimePrompt("DateTimePrompt"));
            _dialogs.Add(new NumberPrompt<int>("numberPrompt"));

            var RoomwaterfallSteps = new WaterfallStep[]
            {
               RoomName,
               RoomStartingDate,
               RoomNumberOfDays,
              RoomConformation
            };
            _dialogs.Add(new WaterfallDialog("Roomdetails", RoomwaterfallSteps));
            _dialogs.Add(new TextPrompt("RoomPrompt"));
            _dialogs.Add(new NumberPrompt<int>("RoomDaysPrompt"));
        }

        public static async Task<DialogTurnResult> IdStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync("textPrompt", new PromptOptions { Prompt = MessageFactory.Text("Please enter the hubble ID") }, cancellationToken);
        }

        public async Task<DialogTurnResult> IDConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var details = await GetEmployeeDetails(stepContext.Result.ToString());
            GetAdaptiveCard(details, stepContext, cancellationToken);
            return await stepContext.EndDialogAsync(cancellationToken);
        }

        //leave
        public static async Task<DialogTurnResult> LeaveName(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync("textPrompt1", new PromptOptions { Prompt = MessageFactory.Text("Please enter your name.") }, cancellationToken);
        }

        public async Task<DialogTurnResult> LeaveStartingDate(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var LeaveProfile = await _accessors.LeaveProfile.GetAsync(stepContext.Context, () => new LeaveProfile(), cancellationToken);
            string response = stepContext.Context.Activity.Text;

            //else if (response.Equals("help", StringComparison.InvariantCultureIgnoreCase))
            //{
            //    // Provide help information.
            //    string message = "Please provide your name";
            //    await stepContext.Context.SendActivityAsync(
            //        message,
            //        cancellationToken: cancellationToken);

            //    // Continue the ordering process, passing in the current order cart.
            //    // context.ActiveDialog.State["stepIndex"] = (int)context.ActiveDialog.State["stepIndex"] -2;
            //    return await stepContext.ReplaceDialogAsync("leavedetails", cancellationToken);
            //}
            //else if (response.Equals("Go back", StringComparison.InvariantCultureIgnoreCase))
            //{
            //    // Provide help information.
            //    string message = "You need to provide one of the options Yes or Cancle";
            //    await stepContext.Context.SendActivityAsync(
            //        message,
            //        cancellationToken: cancellationToken);

            //    // Continue the ordering process, passing in the current order cart.
            //    return await stepContext.ReplaceDialogAsync(leavedetails, cancellationToken);
            //}
            //else
            //{
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();

            switch (topIntent.Value.intent)
            {
                case Cancel:
                    await stepContext.Context.SendActivityAsync("Your leave request has been canceled", cancellationToken: cancellationToken);

                    return await stepContext.EndDialogAsync(null, cancellationToken);

                default:
                    LeaveProfile.Name = (string)recognizerResult.Entities["personName"][0];

                    // We can send messages to the user at any point in the WaterfallStep.
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Thanks {LeaveProfile.Name}."), cancellationToken);
                    await _accessors.LeaveProfile.SetAsync(stepContext.Context, LeaveProfile, cancellationToken);
                    // WaterfallStep always finishes with the end of the Waterfall or with another dialog; here it is a Prompt Dialog.
                    return await stepContext.PromptAsync("textPrompt1", new PromptOptions { Prompt = MessageFactory.Text("Please provide the leave starting date") }, cancellationToken);

            }
            //}
        }


        private async Task<DialogTurnResult> LeaveEndingDate(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var LeaveProfile = await _accessors.LeaveProfile.GetAsync(stepContext.Context, () => new LeaveProfile(), cancellationToken);
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();
            var value = topIntent.Value.intent;
            string response = stepContext.Context.Activity.Text;
            switch (topIntent.Value.intent)
            {
                case Cancel:
                    await stepContext.Context.SendActivityAsync("Your leave request has been canceled", cancellationToken: cancellationToken);

                    return await stepContext.EndDialogAsync(null, cancellationToken);
                case Help:
                    string message = "Please enter the date DD/MM/YYYY or 11 Jan 2019";
                    await stepContext.Context.SendActivityAsync(message, cancellationToken: cancellationToken);
                    //     await stepContext.ContinueDialogAsync(cancellationToken);
                    // context.ActiveDialog.State["stepIndex"] = (int)context.ActiveDialog.State["stepIndex"] -2;
                    //return await stepContext.ReplaceDialogAsync("leavedetails", cancellationToken);
                    return null;
                case Leavedetails:
                    var entityFound = ParseLuisForEntities(value);
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($" {entityFound}"));
                    return null;

                default:

                    LeaveProfile.StartingDate = (DateTime)recognizerResult.Entities["datetime"][0]["timex"][0];
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Thanks {LeaveProfile.Name}, you have provided the leave starting date as {LeaveProfile.StartingDate.ToString("dd/MM/yyyy")}."), cancellationToken);
                    return await stepContext.PromptAsync("textPrompt1", new PromptOptions { Prompt = MessageFactory.Text("Please provide the leave ending date") }, cancellationToken);
            }

        }

        private async Task<DialogTurnResult> LeaveReason(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var LeaveProfile = await _accessors.LeaveProfile.GetAsync(stepContext.Context, () => new LeaveProfile(), cancellationToken);
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();
            var value = topIntent.Value.intent;
            string response = stepContext.Context.Activity.Text;
            switch (topIntent.Value.intent)
            {
                case Cancel:
                    await stepContext.Context.SendActivityAsync("Your leave request has been canceled", cancellationToken: cancellationToken);

                    return await stepContext.EndDialogAsync(null, cancellationToken);
                case Help:
                    string message = "Please enter the date DD/MM/YYYY or 11 Jan 2019";
                    await stepContext.Context.SendActivityAsync(message, cancellationToken: cancellationToken);
                    return null;
                case Leavedetails:
                    var entityFound = ParseLuisForEntities(value);
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($" {entityFound}"));
                    return null;
                default:
                    LeaveProfile.LeaveEndingDate = (DateTime)recognizerResult.Entities["datetime"][0]["timex"][0];
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Thanks {LeaveProfile.Name}, your leave starting date is {LeaveProfile.StartingDate.ToString("dd/MM/yyyy")} and the ending day is {LeaveProfile.LeaveEndingDate.ToString("dd/MM/yyyy")}."), cancellationToken);
                    return await stepContext.PromptAsync("textPrompt1", new PromptOptions { Prompt = MessageFactory.Text("Can you please provide the reason for this leave") }, cancellationToken);
            }

        }

        private async Task<DialogTurnResult> LeaveReasonConformation(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            var LeaveProfile = await _accessors.LeaveProfile.GetAsync(stepContext.Context, () => new LeaveProfile(), cancellationToken);
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();
            string response = stepContext.Context.Activity.Text;
            switch (topIntent.Value.intent)
            {
                case Cancel:
                    await stepContext.Context.SendActivityAsync("Your leave request has been canceled", cancellationToken: cancellationToken);

                    return await stepContext.EndDialogAsync(null, cancellationToken);
                case Help:
                    string message = "Please provide a reason why you want to take a leave";
                    await stepContext.Context.SendActivityAsync(message, cancellationToken: cancellationToken);
                    return null;
                default:
                    LeaveProfile.Reason = (string)stepContext.Result;
                    return await stepContext.PromptAsync("textPrompt1", new PromptOptions
                    {
                        Prompt = MessageFactory.Text($"Thanks you for providing all the information.\n" +
                    $"If you want to confirm the leave please reply 'YES' Or 'CANCEL'")
                    }, cancellationToken);
            }
        }

        private async Task<DialogTurnResult> LeaveConformation(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var LeaveProfile = await _accessors.LeaveProfile.GetAsync(stepContext.Context, () => new LeaveProfile(), cancellationToken);
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();
            string response = stepContext.Context.Activity.Text;
            switch (topIntent.Value.intent)
            {
                case Cancel:
                    await stepContext.Context.SendActivityAsync("Your leave request has been canceled", cancellationToken: cancellationToken);

                    return await stepContext.EndDialogAsync(null, cancellationToken);
                case Help:
                    string message = "Please provide a reason why you want to take a leave";
                    await stepContext.Context.SendActivityAsync(message, cancellationToken: cancellationToken);
                    return null;
                default:
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Thanks {LeaveProfile.Name}, you have applied for leave from {LeaveProfile.StartingDate.ToString("dd/MM/yyyy")} to {LeaveProfile.LeaveEndingDate.ToString("dd/MM/yyyy")}. The reason being '{ LeaveProfile.Reason}'. You will receive an email confirmation"), cancellationToken);
                    return await stepContext.EndDialogAsync(cancellationToken);
            }
        }


        //Room 

        public static async Task<DialogTurnResult> RoomName(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync("RoomPrompt", new PromptOptions { Prompt = MessageFactory.Text("Please enter your name.") }, cancellationToken);

        }

        public async Task<DialogTurnResult> RoomStartingDate(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var RoomProfile = await _accessors.RoomProfile.GetAsync(stepContext.Context, () => new RoomProfile(), cancellationToken);
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();
            string response = stepContext.Context.Activity.Text;
            switch (topIntent.Value.intent)
            {
                case Cancel:
                    await stepContext.Context.SendActivityAsync("Your Room reservation request has been canceled", cancellationToken: cancellationToken);
                    return await stepContext.EndDialogAsync(null, cancellationToken);
                default:

                    RoomProfile.Name = (string)recognizerResult.Entities["personName"][0];
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Thanks {RoomProfile.Name}."), cancellationToken);
                    return await stepContext.PromptAsync("RoomPrompt", new PromptOptions { Prompt = MessageFactory.Text("On which date do you want to book the conference room? ") }, cancellationToken);
            }
        }
        public async Task<DialogTurnResult> RoomNumberOfDays(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var RoomProfile = await _accessors.RoomProfile.GetAsync(stepContext.Context, () => new RoomProfile(), cancellationToken);
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();
            string response = stepContext.Context.Activity.Text;
            switch (topIntent.Value.intent)
            {
                case Cancel:
                    await stepContext.Context.SendActivityAsync("Your Room reservation request has been canceled", cancellationToken: cancellationToken);
                    return await stepContext.EndDialogAsync(null, cancellationToken);
                default:

                    RoomProfile.StartingDate = (DateTime)recognizerResult.Entities["datetime"][0]["timex"][0];
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Thanks {RoomProfile.Name}, your conference room booking for {RoomProfile.StartingDate.ToString("dd/MM/yyyy")} is under process."), cancellationToken);
                    return await stepContext.PromptAsync("RoomDaysPrompt", new PromptOptions { Prompt = MessageFactory.Text("Please provide the number of people attending the conference") }, cancellationToken);
            }
        }

        private async Task<DialogTurnResult> RoomConformation(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            UserProfile userProfile =
                 await _accessors.UserProfileAccessor.GetAsync(stepContext.Context, () => new UserProfile());
            ConversationData conversationData =
              await _accessors.ConversationDataAccessor.GetAsync(stepContext.Context, () => new ConversationData());
            conversationData.Timestamp = stepContext.Context.Activity.Timestamp.ToString();
            conversationData.ChannelId = stepContext.Context.Activity.ChannelId.ToString();
            var RoomProfile = await _accessors.RoomProfile.GetAsync(stepContext.Context, () => new RoomProfile(), cancellationToken);
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();
            string response = stepContext.Context.Activity.Text;
            switch (topIntent.Value.intent)
            {
                case Cancel:
                    await stepContext.Context.SendActivityAsync("Your Room reservation request has been canceled", cancellationToken: cancellationToken);
                    return await stepContext.EndDialogAsync(null, cancellationToken);
                default:

                        RoomProfile.NumberOfDays = (int)stepContext.Result;
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Thanks {RoomProfile.Name} your conference room has been booked on {RoomProfile.StartingDate.ToString("dd/MM/yyyy")}."), cancellationToken);
                    //File.AppendAllText(@"D:\work\Bots\BeckyBot\BeckyBot\EmptyBot\file.txt", $" {PromptedUserForName}" + Environment.NewLine);
                    await stepContext.Context.SendActivityAsync($"Message received at: {conversationData.Timestamp}");
                    await stepContext.Context.SendActivityAsync($"Message received from: {conversationData.ChannelId}");
                   // File.AppendAllText(@"D:\work\Bots\BeckyBot\BeckyBot\EmptyBot\file.txt", $" {stepContext.Context.ToString()}" + Environment.NewLine);
                    return await stepContext.EndDialogAsync(cancellationToken);
            }
        }

        public async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default(CancellationToken))
        {


            //if (turnContext.Activity.Type == ActivityTypes.Message)
            //{
            //    // Get the state properties from the turn context.
            //    UserProfile userProfile =
            //        await _accessors.UserProfileAccessor.GetAsync(turnContext, () => new UserProfile());
            //    ConversationData conversationData =
            //        await _accessors.ConversationDataAccessor.GetAsync(turnContext, () => new ConversationData());

            //    if (string.IsNullOrEmpty(userProfile.Name))
            //    {
            //        // First time around this is set to false, so we will prompt user for name.
            //        if (conversationData.PromptedUserForName)
            //        {
            //            // Set the name to what the user provided
            //            userProfile.Name = turnContext.Activity.Text?.Trim();

            //            // Acknowledge that we got their name.
            //            await turnContext.SendActivityAsync($"Thanks {userProfile.Name}.");

            //            // Reset the flag to allow the bot to go though the cycle again.
            //            conversationData.PromptedUserForName = false;
            //        }
            //        else
            //        {
            //            // Prompt the user for their name.
            //            await turnContext.SendActivityAsync($"What is your name?");

            //            // Set the flag to true, so we don't prompt in the next turn.
            //            conversationData.PromptedUserForName = true;
            //        }

            //        // Save user state and save changes.
            //        await _accessors.UserProfileAccessor.SetAsync(turnContext, userProfile);
            //        await _accessors.UserState.SaveChangesAsync(turnContext);
            //    }
            //    else
            //    {
            //        // Add message details to the conversation data.
            //        conversationData.Timestamp = turnContext.Activity.Timestamp.ToString();
            //        conversationData.ChannelId = turnContext.Activity.ChannelId.ToString();

            //        // Display state data
            //        await turnContext.SendActivityAsync($"{userProfile.Name} sent: {turnContext.Activity.Text}");
            //        await turnContext.SendActivityAsync($"Message received at: {conversationData.Timestamp}");
            //        await turnContext.SendActivityAsync($"Message received from: {conversationData.ChannelId}");
            //    }

            //    // Update conversation state and save changes.
            //    await _accessors.ConversationDataAccessor.SetAsync(turnContext, conversationData);
            //    await _accessors.ConversationState.SaveChangesAsync(turnContext);
            //}



            if (turnContext == null)
            {
                throw new ArgumentNullException(nameof(turnContext));
            }
            if (turnContext.Activity.Type == ActivityTypes.Message && !turnContext.Responded)
            {
                ConversationData conversationData =
              await _accessors.ConversationDataAccessor.GetAsync(turnContext,() => new ConversationData());

                // Get the intent recognition result
                var recognizerResult = await _services.LuisServices[DispatchKey].RecognizeAsync(turnContext, cancellationToken);
                var topIntent = recognizerResult?.GetTopScoringIntent();
                if (topIntent == null)
                {
                    await turnContext.SendActivityAsync("Unable to get the top intent.");
                }
                else
                {
                    await DispatchToTopIntentAsync(turnContext, topIntent, cancellationToken);

                }
                //Save the dialog state into the conversation state.
                await _accessors.ConversationDataAccessor.SetAsync(turnContext, conversationData);
                await _accessors.ConversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            }

           
        }
        const string Greeting = "Greeting";
        const string GeneralInformation = "GeneralInformation";
        const string EmployeeID = "EmployeeID";
        const string Room = "Room";
        const string Leave = "Leave";
        const string Cancel = "Cancel";
        const string Help = "Help";
        const string Leavedetails = "Leavedetails";

        private async Task DispatchToTopIntentAsync(ITurnContext context, (string intent, double score)? topIntent, CancellationToken cancellationToken = default(CancellationToken))
        {
            const string HRSAPLuis = "HRSAPLuis";
            
            const string HRSAPQnA = "HRSAPQnA";

            switch (topIntent.Value.intent)
            {
                case HRSAPLuis:
                    await DispatchToLuisModelAsync(context, LuisKey);

                    // Here, you can add code for calling the hypothetical home automation service, passing in any entity information that you need
                    break;
                
                case HRSAPQnA:
                    await DispatchToQnAMakerAsync(context, QnAKey);
                    break;

                default:
                    // The intent didn't match any case, so just display the recognition results.
                    await context.SendActivityAsync($"Dispatch intent: {topIntent.Value.intent} ({topIntent.Value.score}).");
                    break;
            }
        }

        private async Task DispatchToLuisModelAsync(ITurnContext turnContext, string appName, CancellationToken cancellationToken = default(CancellationToken))
        {
            var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(turnContext, cancellationToken);
            var topIntent = recognizerResult?.GetTopScoringIntent();



            var dialogContext = await _dialogs.CreateContextAsync(turnContext, cancellationToken);
            var results = await dialogContext.ContinueDialogAsync(cancellationToken);

            if (results.Status == DialogTurnStatus.Empty)
            {
                // Check LUIS model
                // var recognizerResult = await _services.LuisServices[LuisKey].RecognizeAsync(turnContext, cancellationToken);
                //var topIntent = recognizerResult?.GetTopScoringIntent();

                switch (topIntent.Value.intent)
                {
                    //case Greeting:


                    //    break;
                    //case GeneralInformation:
                    //    await turnContext.SendActivityAsync($"I can help you perform SAP related tasks.\n" +
                    //        $"1. Search employee ID\n" +
                    //         $"2. Apply for leave \n" +
                    //        $"3. Reserve a conference room \n");
                    //    break;
                    case EmployeeID:

                        await dialogContext.BeginDialogAsync("details", null, cancellationToken);
                        break;
                    case Leave:
                        await dialogContext.BeginDialogAsync("leavedetails", null, cancellationToken);

                        break;
                    case Room:
                        await dialogContext.BeginDialogAsync("Roomdetails", null, cancellationToken);
                        break;
                        //default:
                        //    await turnContext.SendActivityAsync("I am unable to understand that. I am very sorry for not being able to assit you on this.");
                        //    break;


                }
            }
        }

        private async Task DispatchToQnAMakerAsync(ITurnContext turnContext, string appName, CancellationToken cancellationToken = default(CancellationToken))
        {
            if (!string.IsNullOrEmpty(turnContext.Activity.Text))
            {
                var results1 = await _services.QnAServices[QnAKey].GetAnswersAsync(turnContext);
                if (results1.Any())
                {
                    await turnContext.SendActivityAsync(results1.First().Answer, cancellationToken: cancellationToken);
                }
                else
                {
                    await turnContext.SendActivityAsync($"Couldn't find an answer in the {appName}.");
                }
            }
        }

        private async Task<EmployeeDetailsModel> GetEmployeeDetails(string employeeID)
        {
            var userModel = new EmployeeDetailsModel();
            var model = new { SearchKey = employeeID, Authorization = "YWRtaW46YWRtaW4=" };
            var data = JsonConvert.SerializeObject(model);
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            HttpResponseMessage response = await client.PostAsync($"https://www.miraclesoft.com/HubbleServices/hubbleresources/mconEmployeeServices/getMconEmployeeSuggestionList", new StringContent(data, Encoding.UTF8, "application/json"));
            if (response.IsSuccessStatusCode)
            {
                var str = await response.Content.ReadAsStringAsync();
                userModel = JsonConvert.DeserializeObject<EmployeeDetailsModel>(str);
                if (userModel.IsDataExisted != false & userModel.EmployeeList.Count > 1)
                {
                    return null;
                }
                else
                {
                    return userModel;
                }
            }
            else
            {
                return null;
            }
        }
        private Attachment GetAdaptiveCard(EmployeeDetailsModel employees, WaterfallStepContext turnContext, CancellationToken cancellationToken)
        {
            var heroCard = new HeroCard
            {
                Title = employees.EmployeeList[0].EmployeeName + '\n' + employees.EmployeeList[0].Designation,
                Subtitle = employees.EmployeeList[0].CellPhoneNo,
                Tap = new CardAction(ActionTypes.OpenUrl, "Learn More", value: $"https://www.miraclesoft.com/images/employee-profile-pics/{employees.EmployeeList[0].LoginId}.png"),
                Text = employees.EmployeeList[0].Location,
                Images = new List<CardImage> { new CardImage($"https://www.miraclesoft.com/images/employee-profile-pics/{employees.EmployeeList[0].LoginId}.png") },
            };
            var response = turnContext.Context.Activity.CreateReply();
            response.Attachments = new List<Attachment>()
            {
                heroCard.ToAttachment()
            };
            turnContext.Context.SendActivityAsync(response, cancellationToken);
            return heroCard.ToAttachment();
        }

        private string ParseLuisForEntities(string value)
        {
            var result = string.Empty;
            if (value == Leavedetails)
            {
                const string Leaves = "You have 5 leaves left.";

                return Leaves;
            }

            return result;
        }
    }

}

