﻿using System;

namespace EmptyBot
{
    public class RoomProfile
    {
        public string Name { get; set; }

        public DateTime StartingDate { get; set; }

        public int NumberOfDays { get; set; }

    }
}
