﻿using System;

namespace EmptyBot
{
    public class LeaveProfile
    {
        public string Name { get; set; }

        public DateTime StartingDate { get; set; }

        public DateTime LeaveEndingDate { get; set; }

        public string Reason { get; set; }

    }
}
