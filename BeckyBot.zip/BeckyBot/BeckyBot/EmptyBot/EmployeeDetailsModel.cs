﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace EmptyBot
{
    public class EmployeeDetailsModel
    {
        [JsonProperty("isDataExisted")]
        public bool IsDataExisted { get; set; }

        [JsonProperty("IsAuthenticate")]
        public bool IsAuthenticate { get; set; }

        [JsonProperty("employees")]
        public List<Employees> EmployeeList { get; set; }
    }

    public class Employees
    {
        [JsonProperty("Designation")]
        public string Designation { get; set; }

        [JsonProperty("CellPhoneNo")]
        public string CellPhoneNo { get; set; }

        [JsonProperty("LoginId")]
        public string LoginId { get; set; }

        [JsonProperty("FirstName")]
        public string FirstName { get; set; }

        [JsonProperty("AboutMe")]
        public string AboutMe { get; set; }

        [JsonProperty("MiddleName")]
        public string MiddleName { get; set; }

        [JsonProperty("Image")]
        public string Image { get; set; }

        [JsonProperty("IsOperationContactTeam")]
        public string IsOperationContactTeam { get; set; }

        [JsonProperty("CoverPic")]
        public string CoverPic { get; set; }

        [JsonProperty("MconPushToken")]
        public string MconPushToken { get; set; }

        [JsonProperty("AliasName")]
        public string AliasName { get; set; }

        [JsonProperty("HireDate")]
        public string HireDate { get; set; }

        [JsonProperty("Email1")]
        public string Email1 { get; set; }

        [JsonProperty("ReportsTo")]
        public string ReportsTo { get; set; }

        [JsonProperty("LastName")]
        public string LastName { get; set; }

        [JsonProperty("WorkPhoneNo")]
        public string WorkPhoneNo { get; set; }

        [JsonProperty("SkillSet")]
        public string SkillSet { get; set; }

        [JsonProperty("EmployeeName")]
        public string EmployeeName { get; set; }

        [JsonProperty("Location")]
        public string Location { get; set; }

    }
}
